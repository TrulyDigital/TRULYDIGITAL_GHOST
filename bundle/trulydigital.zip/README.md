# TrulyDigital.tech 
# Ghost Template

**Objetivo General**
